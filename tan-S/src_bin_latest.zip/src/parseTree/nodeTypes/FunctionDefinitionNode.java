package parseTree.nodeTypes;

import parseTree.ParseNode;
import parseTree.ParseNodeVisitor;
import tokens.Token;

public class FunctionDefinitionNode extends ParseNode {
    public FunctionDefinitionNode(Token token) {
        super(token);
    }

    public FunctionDefinitionNode(ParseNode node) {
        super(node);
    }

    // children order: returnType, functionName, parameterList, functionBody
    public static FunctionDefinitionNode withChildren(ParseNode returnType, ParseNode functionName, ParseNode parameterList, ParseNode functionBody) {
        FunctionDefinitionNode node = new FunctionDefinitionNode(returnType.getToken());
        node.appendChild(returnType);
        node.appendChild(functionName);
        node.appendChild(parameterList);
        node.appendChild(functionBody);
        return node;
    }

    // other methods...
    public void accept(ParseNodeVisitor visitor) {
        visitor.visitEnter(this);
        super.visitChildren(visitor);
        visitor.visitLeave(this);
    }
}
