package parseTree.nodeTypes;

import parseTree.ParseNode;
import parseTree.ParseNodeVisitor;
import tokens.Token;

public class ReturnStatementNode extends ParseNode {
    public ReturnStatementNode(Token token) {
        super(token);
    }

    public ReturnStatementNode(ParseNode node) {
        super(node);
    }

    // children order: returnExpression
    public static ReturnStatementNode withChildren(ParseNode returnExpression) {
        ReturnStatementNode node = new ReturnStatementNode(returnExpression.getToken());
        node.appendChild(returnExpression);
        return node;
    }

    // other methods...
    public void accept(ParseNodeVisitor visitor) {
        visitor.visitEnter(this);
        super.visitChildren(visitor);
        visitor.visitLeave(this);
    }
}