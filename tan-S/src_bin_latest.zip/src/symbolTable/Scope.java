package symbolTable;

import inputHandler.TextLocation;
import logging.TanLogger;
import parseTree.nodeTypes.IdentifierNode;
import semanticAnalyzer.types.Type;
import tokens.Token;

import java.util.List;

public class Scope {
	private Scope baseScope;
	private MemoryAllocator allocator;
	private SymbolTable symbolTable;

//////////////////////////////////////////////////////////////////////
// factories

	public static Scope createProgramScope() {
		return new Scope(programScopeAllocator(), nullInstance());
	}
	public Scope createSubscope() {
		return new Scope(allocator, this);
	}
	// In Scope
	public Scope createParameterScope(MemoryAllocator allocator, Scope parent) {
		return new ParameterScope(allocator, parent);
	}

	public Scope createProcedureScope() {
		// Allocate extra 8 bytes for the runtime system's use
		MemoryAllocator procedureAllocator = new ParameterMemoryAllocator(MemoryAccessMethod.DIRECT_ACCESS_BASE, MemoryLocation.GLOBAL_VARIABLE_BLOCK);
		procedureAllocator.allocate(8);
		return new Scope(procedureAllocator, this);
	}
	private static MemoryAllocator programScopeAllocator() {
		return new PositiveMemoryAllocator(
				MemoryAccessMethod.DIRECT_ACCESS_BASE,
				MemoryLocation.GLOBAL_VARIABLE_BLOCK);
	}

	//////////////////////////////////////////////////////////////////////
// private constructor.
	public Scope(MemoryAllocator allocator, Scope baseScope) {
		super();
		this.baseScope = (baseScope == null) ? this : baseScope;
		this.symbolTable = new SymbolTable();

		this.allocator = allocator;
		allocator.saveState();
	}

	///////////////////////////////////////////////////////////////////////
//  basic queries
	public Scope getBaseScope() {
		return baseScope;
	}
	public MemoryAllocator getAllocationStrategy() {
		return allocator;
	}
	public SymbolTable getSymbolTable() {
		return symbolTable;
	}

	///////////////////////////////////////////////////////////////////////
//memory allocation
	// must call leave() when destroying/leaving a scope.
	public void leave() {
		//System.out.println("Leaving scope with symbol table: " + symbolTable);
		allocator.restoreState();
	}
	public int getAllocatedSize() {
		return allocator.getMaxAllocatedSize();
	}

	///////////////////////////////////////////////////////////////////////
	//bindings
	public Binding createBinding(IdentifierNode identifierNode, Type type, boolean isMutable) {

		Token token = identifierNode.getToken();
		symbolTable.errorIfAlreadyDefined(token);

		String lexeme = token.getLexeme();
		//System.out.println("Installing binding for " + lexeme + " in symbol table: " + symbolTable.hashCode());

		Binding binding = allocateNewBinding(type, token.getLocation(), lexeme, isMutable);
		symbolTable.install(lexeme, binding);
		//System.out.println("Installed binding for " + lexeme + " in symbol table: " + symbolTable);

		return binding;
	}
	private Binding allocateNewBinding(Type type, TextLocation textLocation, String lexeme, boolean isMutable) {
		MemoryLocation memoryLocation = allocator.allocate(type.getSize());
		return new Binding(type, textLocation, memoryLocation, lexeme, isMutable);
	}
	//Function
	public FunctionBinding createFunctionBinding(IdentifierNode functionIdentifier, Type returnType, List<Type> parameterTypes, boolean isMutable) {
		Token token = functionIdentifier.getToken();
		symbolTable.errorIfAlreadyDefined(token);

		String lexeme = token.getLexeme();
		FunctionBinding binding = allocateNewFunctionBinding(returnType, parameterTypes, token.getLocation(), lexeme, isMutable);
		symbolTable.installFunction(lexeme, binding);

		return binding;
	}

	private FunctionBinding allocateNewFunctionBinding(Type returnType, List<Type> parameterTypes, TextLocation textLocation, String lexeme, boolean isMutable) {
		MemoryLocation memoryLocation = allocator.allocate(1); // Function bindings do not use memory, so we allocate a single placeholder unit
		return new FunctionBinding(returnType, parameterTypes, textLocation, memoryLocation, lexeme, isMutable);
	}

	///////////////////////////////////////////////////////////////////////
//toString
	public String toString() {
		String result = "scope: ";
		result += " hash "+ hashCode() + "\n";
		result += symbolTable;
		return result;
	}

	////////////////////////////////////////////////////////////////////////////////////
//Null Scope object - lazy singleton (Lazy Holder) implementation pattern
	public static Scope nullInstance() {
		return NullScope.instance;
	}
	private static class NullScope extends Scope {
		private static NullScope instance = new NullScope();

		private NullScope() {
			super(    new PositiveMemoryAllocator(MemoryAccessMethod.NULL_ACCESS, "", 0),
					null);
		}
		public String toString() {
			return "scope: the-null-scope";
		}
		@Override
		public Binding createBinding(IdentifierNode identifierNode, Type type, boolean isMutable) {
			unscopedIdentifierError(identifierNode.getToken());
			return super.createBinding(identifierNode, type, isMutable);
		}

		// subscopes of null scope need their own strategy.  Assumes global block is static.
		public Scope createSubscope() {
			return new Scope(programScopeAllocator(), this);
		}
	}


	///////////////////////////////////////////////////////////////////////
//error reporting
	private static void unscopedIdentifierError(Token token) {
		TanLogger log = TanLogger.getLogger("compiler.scope");
		log.severe("variable " + token.getLexeme() +
				" used outside of any scope at " + token.getLocation());
	}

	public boolean containsBinding(String lexeme) {
		return symbolTable.containsKey(lexeme);
	}

	public Binding lookup(String identifier) {
		return symbolTable.lookup(identifier);
	}

	public FunctionBinding lookupFunction(String identifier) {
		Binding binding = symbolTable.lookup(identifier);
		if (binding instanceof FunctionBinding) {
			return (FunctionBinding) binding;
		}
		return null;
	}
}
