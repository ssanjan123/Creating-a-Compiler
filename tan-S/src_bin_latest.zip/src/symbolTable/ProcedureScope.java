package symbolTable;

import inputHandler.TextLocation;
import parseTree.nodeTypes.IdentifierNode;
import semanticAnalyzer.types.Type;
import tokens.Token;

public class ProcedureScope extends Scope {
    private SymbolTable table;
    private int size;

    public ProcedureScope(MemoryAllocator allocator, Scope parent, int size) {
        super(allocator, parent);
        this.size = size;
        table = new SymbolTable();
        allocator.allocate(size); // Allocate space for runtime system.
    }

    @Override
    public Binding createBinding(IdentifierNode idNode, Type type, boolean isMutable) {
        Token token = idNode.getToken();

        table.errorIfAlreadyDefined(token);

        String lexeme = token.getLexeme();
        Binding binding = allocateNewBinding(type, token.getLocation(), lexeme, isMutable);
        table.install(lexeme, binding);

        return binding;
    }

    private Binding allocateNewBinding(Type type, TextLocation textLocation, String lexeme, boolean isMutable) {
        MemoryLocation memoryLocation = getAllocationStrategy().allocate(type.getSize());
        return new Binding(type, textLocation, memoryLocation, lexeme, isMutable);
    }

    @Override
    public Binding lookup(String name) {
        return table.lookup(name);
    }

    @Override
    public void leave() {
        ((ParameterMemoryAllocator)getAllocationStrategy()).adjustOffsets();
        super.leave();
    }
}
