package symbolTable;

import inputHandler.TextLocation;
import parseTree.nodeTypes.IdentifierNode;
import semanticAnalyzer.types.Type;
import tokens.Token;

import java.util.ArrayList;
import java.util.List;

public class ParameterScope extends Scope {

    private SymbolTable table;

    public ParameterScope(MemoryAllocator allocator, Scope parent) {
        super(allocator, parent);
        table = new SymbolTable();
        //System.out.println("New Symbol table for param" + table.hashCode());

    }

    @Override
    public SymbolTable getSymbolTable() {
        return table;
    }

    @Override
    public Binding createBinding(IdentifierNode idNode, Type type, boolean isMutable) {
        Token token = idNode.getToken();
        table.errorIfAlreadyDefined(token);

        String lexeme = token.getLexeme();
        Binding binding = allocateNewBinding(type, token.getLocation(), lexeme, false);
        //System.out.println("Installing binding for " + lexeme + " in symbol table: " + table.hashCode());
        table.install(lexeme, binding);
        //System.out.println("Installed binding for " + lexeme + " in symbol table: " + table);
        return binding;
    }


    private Binding allocateNewBinding(Type type, TextLocation textLocation, String lexeme, boolean isMutable) {
        MemoryLocation memoryLocation = getAllocationStrategy().allocate(type.getSize());
        return new Binding(type, textLocation, memoryLocation, lexeme, isMutable);
    }

    @Override
    public Binding lookup(String name) {
        return table.lookup(name);
    }

    @Override
    public void leave() {
        super.leave();
        if(getAllocationStrategy() instanceof ParameterMemoryAllocator) {
            //System.out.println("Adjusting offsets for ParameterMemoryAllocator");
            ((ParameterMemoryAllocator)getAllocationStrategy()).adjustOffsets();
        }
    }


}