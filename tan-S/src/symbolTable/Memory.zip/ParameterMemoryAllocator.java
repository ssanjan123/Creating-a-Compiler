package symbolTable;

import java.util.ArrayList;
import java.util.List;

public class ParameterMemoryAllocator implements MemoryAllocator {

    private NegativeMemoryAllocator allocator;
    private List<MemoryLocation> allocatedLocations;
    private List<Integer> savedStates;

    public ParameterMemoryAllocator(MemoryAccessMethod accessor, String baseAddress) {
        allocator = new NegativeMemoryAllocator(accessor, baseAddress);
        allocatedLocations = new ArrayList<>();
        savedStates = new ArrayList<>();
    }

    @Override
    public MemoryLocation allocate(int size) {
        MemoryLocation location = allocator.allocate(size);
        allocatedLocations.add(location);
        return location;
    }

    @Override
    public String getBaseAddress() {
        return allocator.getBaseAddress();
    }

    @Override
    public void saveState() {
        //System.out.print("SAved Param");
        // Saving the current state for future restore.
        savedStates.add(allocatedLocations.size());
    }

    @Override
    public void restoreState() {
        //System.out.print("restored Param ");
        // Check if there are any bookmarks
        if (savedStates.isEmpty()) {
            adjustOffsets();
        } else {
            // Removing locations added after the saved state.
            int lastSavedState = savedStates.remove(savedStates.size() - 1);
            while (allocatedLocations.size() > lastSavedState) {
                allocatedLocations.remove(allocatedLocations.size() - 1);
            }
        }
        //allocator.restoreState();
    }

    public void adjustOffsets() {
        int adjustment = allocator.getMaxAllocatedSize();
        for(MemoryLocation location : allocatedLocations) {
            location.adjustOffset(adjustment);
        }
    }

    @Override
    public int getMaxAllocatedSize() {
        return allocator.getMaxAllocatedSize();
    }

}
